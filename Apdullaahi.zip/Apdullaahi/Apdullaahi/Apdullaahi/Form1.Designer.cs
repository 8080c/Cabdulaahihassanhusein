﻿namespace Apdullaahi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            Exitt = new Button();
            Clearr = new Button();
            Submitt = new Button();
            Extra = new CheckBox();
            Courses = new ListBox();
            OutPut = new Label();
            groupBox2 = new GroupBox();
            Dumar = new RadioButton();
            Rag = new RadioButton();
            StA = new TextBox();
            Stidd = new TextBox();
            StN = new TextBox();
            StAge = new Label();
            StID = new Label();
            stname = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Exitt);
            groupBox1.Controls.Add(Clearr);
            groupBox1.Controls.Add(Submitt);
            groupBox1.Controls.Add(Extra);
            groupBox1.Controls.Add(Courses);
            groupBox1.Controls.Add(OutPut);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Location = new Point(180, 100);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(405, 637);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Student Management";
            // 
            // Exitt
            // 
            Exitt.Location = new Point(267, 403);
            Exitt.Name = "Exitt";
            Exitt.Size = new Size(112, 34);
            Exitt.TabIndex = 5;
            Exitt.Text = "Exit:";
            Exitt.UseVisualStyleBackColor = true;
            Exitt.Click += Exitt_Click;
            // 
            // Clearr
            // 
            Clearr.Location = new Point(149, 403);
            Clearr.Name = "Clearr";
            Clearr.Size = new Size(112, 34);
            Clearr.TabIndex = 5;
            Clearr.Text = "Clear:";
            Clearr.UseVisualStyleBackColor = true;
            Clearr.Click += Clearr_Click;
            // 
            // Submitt
            // 
            Submitt.Location = new Point(31, 403);
            Submitt.Name = "Submitt";
            Submitt.Size = new Size(112, 34);
            Submitt.TabIndex = 5;
            Submitt.Text = "Submit:";
            Submitt.UseVisualStyleBackColor = true;
            Submitt.Click += Submitt_Click;
            // 
            // Extra
            // 
            Extra.AutoSize = true;
            Extra.Location = new Point(234, 252);
            Extra.Name = "Extra";
            Extra.Size = new Size(158, 29);
            Extra.TabIndex = 4;
            Extra.Text = "Extra-curricular:";
            Extra.UseVisualStyleBackColor = true;
            // 
            // Courses
            // 
            Courses.FormattingEnabled = true;
            Courses.ItemHeight = 25;
            Courses.Items.AddRange(new object[] { "Java", "C#", "HTML&CSS3", "React" });
            Courses.Location = new Point(31, 252);
            Courses.Name = "Courses";
            Courses.Size = new Size(180, 129);
            Courses.TabIndex = 3;
            // 
            // OutPut
            // 
            OutPut.BackColor = Color.FromArgb(255, 224, 192);
            OutPut.Location = new Point(31, 449);
            OutPut.Name = "OutPut";
            OutPut.Size = new Size(348, 170);
            OutPut.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(Dumar);
            groupBox2.Controls.Add(Rag);
            groupBox2.Controls.Add(StA);
            groupBox2.Controls.Add(Stidd);
            groupBox2.Controls.Add(StN);
            groupBox2.Controls.Add(StAge);
            groupBox2.Controls.Add(StID);
            groupBox2.Controls.Add(stname);
            groupBox2.Location = new Point(31, 20);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(340, 207);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "StudentInfo";
            // 
            // Dumar
            // 
            Dumar.AutoSize = true;
            Dumar.BackColor = Color.White;
            Dumar.Location = new Point(203, 163);
            Dumar.Name = "Dumar";
            Dumar.Size = new Size(97, 29);
            Dumar.TabIndex = 2;
            Dumar.TabStop = true;
            Dumar.Text = "Female:";
            Dumar.UseVisualStyleBackColor = false;
            // 
            // Rag
            // 
            Rag.AutoSize = true;
            Rag.BackColor = Color.White;
            Rag.Location = new Point(73, 163);
            Rag.Name = "Rag";
            Rag.Size = new Size(79, 29);
            Rag.TabIndex = 2;
            Rag.TabStop = true;
            Rag.Text = "Male:";
            Rag.UseVisualStyleBackColor = false;
            // 
            // StA
            // 
            StA.Location = new Point(174, 114);
            StA.Name = "StA";
            StA.Size = new Size(150, 31);
            StA.TabIndex = 1;
            // 
            // Stidd
            // 
            Stidd.Location = new Point(174, 76);
            Stidd.Name = "Stidd";
            Stidd.Size = new Size(150, 31);
            Stidd.TabIndex = 1;
            // 
            // StN
            // 
            StN.Location = new Point(174, 30);
            StN.Name = "StN";
            StN.Size = new Size(150, 31);
            StN.TabIndex = 1;
            // 
            // StAge
            // 
            StAge.BackColor = Color.White;
            StAge.Location = new Point(16, 114);
            StAge.Name = "StAge";
            StAge.Size = new Size(136, 31);
            StAge.TabIndex = 0;
            StAge.Text = "Student Age:";
            StAge.TextAlign = ContentAlignment.TopRight;
            // 
            // StID
            // 
            StID.BackColor = Color.White;
            StID.Location = new Point(16, 76);
            StID.Name = "StID";
            StID.Size = new Size(136, 31);
            StID.TabIndex = 0;
            StID.Text = "Student ID:";
            StID.TextAlign = ContentAlignment.TopRight;
            // 
            // stname
            // 
            stname.BackColor = Color.White;
            stname.Location = new Point(16, 30);
            stname.Name = "stname";
            stname.Size = new Size(136, 35);
            stname.TabIndex = 0;
            stname.Text = "Student Name:";
            stname.TextAlign = ContentAlignment.TopRight;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1059, 749);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private CheckBox Extra;
        private ListBox Courses;
        private RadioButton Rag;
        private TextBox StN;
        private Label stname;
        private Button Submitt;
        private Button Exitt;
        private Button Clearr;
        private Label OutPut;
        private GroupBox groupBox2;
        private TextBox StA;
        private Label StAge;
        private Label StID;
        private TextBox Stidd;
        private RadioButton Dumar;
    }
}
