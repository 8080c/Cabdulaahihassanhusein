using System;
using System.Xml.Linq;

namespace Apdullaahi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Submitt_Click(object sender, EventArgs e)
        {
            String Name = StN.Text;
            String gender = "";
            double Num,Age, ID;

            if (double.TryParse(StN.Text, out Num))
            {
                MessageBox.Show("Invalid Name!", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                StN.Clear();
                StN.Focus();
                return;
            }
            else
            {
                Name = StN.Text;
            }

            if (!double.TryParse(Stidd.Text, out ID))
            {
                MessageBox.Show("Invalid ID", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Stidd.Clear();
                Stidd.Focus();
                return;
            }

            if (!double.TryParse(StA.Text, out Age))
            {
                MessageBox.Show("Invalid Age", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                StA.Clear();
                StA.Focus();
                return;
            }

            if (Age < 18)
            {
                MessageBox.Show("You can't enrol this course becouse you are young", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (Age > 30)
            {
                MessageBox.Show("You can't enrol this course becouse you are old", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (Dumar.Checked == true)
            {
                gender = "Female";
            }
            else if (Rag.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                MessageBox.Show("You must choose Male or Female", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string Cource = "";



            string extra_click = "";

            if (Courses.SelectedIndex != -1)
            {
                Cource = Courses.SelectedItem.ToString();

                extra_click = "Yes";

                switch (Cource)
                {
                    case "Java":
                        OutPut.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "C#":
                        OutPut.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                        break;
                    case "HTML&CSS3":
                        OutPut.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "React":
                        OutPut.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                            "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource;

                        break;



                }
            }
            else
            {
                MessageBox.Show("please choose at least one course.", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Extra.Checked)
            {
                extra_click = "yes";
                OutPut.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                           "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource + "\n" + "The Extra is:" + extra_click;
            }
            else
            {
                //no
            }
            StN.Focus();
        }

        private void Clearr_Click(object sender, EventArgs e)
        {
            OutPut.Text = "";
            Rag.Checked = false;
            Dumar.Checked = false;
            StN.Text = "";
            Stidd.Text = "";
            StA.Text = "";
            Courses.ClearSelected();
            Extra.Checked = false;
        }

        private void Exitt_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

